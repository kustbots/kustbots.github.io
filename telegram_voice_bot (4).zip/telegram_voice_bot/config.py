"""
Configuration settings for Telegram Voice Chat Bot
"""
import os

# ============== CONFIGURATION ==============
BOT_TOKEN = os.environ.get("BOT_TOKEN", "8715810352:AAETwbBLXTQO6aL6xBh4D14Yn-UaPSzDdzM")
API_ID = int(os.environ.get("API_ID", "29568441"))
API_HASH = os.environ.get("API_HASH", "b32ec0fb66d22da6f77d355fbace4f2a")

# Owner ID - only this user can control the bot
OWNER_ID = int(os.environ.get("OWNER_ID", "7618467489"))

# File paths for data storage
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
SESSIONS_FILE = os.path.join(DATA_DIR, "sessions.json")
CONNECTED_CHANNEL_FILE = os.path.join(DATA_DIR, "connected_channel.json")
LAST_MSG_ID_FILE = os.path.join(DATA_DIR, "last_msg_id.json")

# Reaction emojis for auto-reaction
REACTION_EMOJIS = [
    "👍", "❤️", "🔥", "🎉", "👏", "😊", "🤔", "😍", "😎", "🚀",
    "💯", "⚡", "🌟", "💪", "🙌"
]

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)
