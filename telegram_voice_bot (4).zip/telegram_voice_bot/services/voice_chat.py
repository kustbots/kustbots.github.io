"""
Voice Chat Manager Service
Handles voice chat join/leave operations
"""
import os
import struct
import asyncio
from typing import Tuple, Dict, Any

from pyrogram import Client
from pyrogram.raw import functions, types
from pytgcalls import PyTgCalls
from pytgcalls.exceptions import NoActiveGroupCall

from utils.helpers import get_group_call_input


class VoiceChatManager:
    """Manages voice chat operations"""
    
    def __init__(self, session_manager):
        self.session_manager = session_manager
        self.call_apps = {}  # Store PyTgCalls instances for each client
        self.silent_file = "silent_audio.wav"
        self._create_silent_audio()

    def _create_silent_audio(self):
        """Generates a valid silent WAV file to keep VC alive"""
        if not os.path.exists(self.silent_file):
            # Parameters for a valid WAV header
            num_channels = 1
            sample_rate = 48000
            bits_per_sample = 16
            num_samples = sample_rate * 1  # 1 second of silence
            
            with open(self.silent_file, 'wb') as f:
                # RIFF header
                f.write(b'RIFF')
                f.write(struct.pack('<I', 36 + num_samples * num_channels * bits_per_sample // 8))
                f.write(b'WAVE')
                # fmt chunk
                f.write(b'fmt ')
                f.write(struct.pack('<I', 16))  # Chunk size
                f.write(struct.pack('<H', 1))   # Audio format (PCM)
                f.write(struct.pack('<H', num_channels))
                f.write(struct.pack('<I', sample_rate))
                f.write(struct.pack('<I', sample_rate * num_channels * bits_per_sample // 8))  # Byte rate
                f.write(struct.pack('<H', num_channels * bits_per_sample // 8))  # Block align
                f.write(struct.pack('<H', bits_per_sample))
                # data chunk
                f.write(b'data')
                f.write(struct.pack('<I', num_samples * num_channels * bits_per_sample // 8))
                # Silent data (zeros)
                f.write(b'\x00' * (num_samples * num_channels * bits_per_sample // 8))

    async def join_voice_chat(self, client: Client, chat_identifier) -> Tuple[bool, str]:
        """Join a voice chat using py-tgcalls and remain muted"""
        
        # Check if we already have a PyTgCalls instance for this client
        if client not in self.call_apps:
            app = PyTgCalls(client)
            await app.start()
            self.call_apps[client] = app
        
        app = self.call_apps[client]

        try:
            # Use py-tgcalls to join and play silent audio
            # This creates a stable connection preventing auto-leave
            await app.play(chat_identifier, self.silent_file)
                
            return True, "**Joined VC!**"
            
        except NoActiveGroupCall:
            return False, "**No Active VC!**"
        except Exception as e:
            print(f"Error: {e}")
            return False, str(e)

    async def leave_voice_chat(self, client: Client, chat_identifier) -> Tuple[bool, str]:
        """Leave voice chat"""
        try:
            if client in self.call_apps:
                app = self.call_apps[client]
                try:
                    await app.leave_call(chat_identifier)
                    return True, "Successfully left voice chat"
                except Exception:
                    pass
            
            # Fallback raw method
            call = await get_group_call_input(client, chat_identifier)
            if call:
                await client.invoke(
                    functions.phone.LeaveGroupCall(
                        call=call,
                        source=0
                    )
                )
                return True, "Successfully left voice chat"
            return True, "Left voice chat (or no active call)"
        except Exception as e:
            return False, str(e)
    
    async def join_all_to_voice_chat(self, chat_identifier: str) -> Tuple[list, list]:
        """Join all sessions to a voice chat"""
        
        joined = []
        failed = []
        
        for session_key, data in self.session_manager.user_clients.items():
            try:
                user_client = data["client"]
                me = data.get("me")
                
                success, msg = await self.join_voice_chat(user_client, chat_identifier)
                
                name = me.first_name if me and me.first_name else session_key[:10]
                
                if success:
                    joined.append(name)
                else:
                    failed.append((name, msg))
                
            except Exception as e:
                me = data.get("me")
                name = me.first_name if me and me.first_name else session_key[:10]
                failed.append((name, str(e)[:50]))
            
            await asyncio.sleep(0.5)
        
        return joined, failed
    
    async def leave_all_from_voice_chat(self, chat_identifier: str) -> Tuple[list, list]:
        """Leave all sessions from a voice chat"""
        
        left = []
        failed = []
        
        for session_key, data in self.session_manager.user_clients.items():
            try:
                user_client = data["client"]
                me = data.get("me")
                
                success, msg = await self.leave_voice_chat(user_client, chat_identifier)
                
                name = me.first_name if me and me.first_name else session_key[:10]
                if success:
                    left.append(name)
                else:
                    failed.append((name, msg))
                
            except Exception as e:
                me = data.get("me")
                name = me.first_name if me and me.first_name else session_key[:10]
                failed.append((name, str(e)[:50]))
        
        return left, failed