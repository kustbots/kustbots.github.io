"""
Helper utility functions
"""
import json
import random
from typing import Optional

from pyrogram import Client
from pyrogram.types import Message
from pyrogram.raw import functions, types

from config import OWNER_ID


async def is_owner(message: Message) -> bool:
    """Check if the user is the owner"""
    return message.from_user.id == OWNER_ID


async def get_group_call_input(client: Client, chat_identifier):
    """Get the InputGroupCall object for a chat."""
    try:
        chat_peer = await client.resolve_peer(chat_identifier)
        
        if isinstance(chat_peer, types.InputPeerChannel):
            full_chat_response = await client.invoke(
                functions.channels.GetFullChannel(channel=chat_peer)
            )
            full_chat = full_chat_response.full_chat
        elif isinstance(chat_peer, types.InputPeerChat):
            full_chat_response = await client.invoke(
                functions.messages.GetFullChat(chat_id=chat_peer.chat_id)
            )
            full_chat = full_chat_response.full_chat
        else:
            return None
        
        if hasattr(full_chat, 'call') and full_chat.call:
            return full_chat.call
        return None
    except Exception as e:
        print(f"Error getting group call input: {e}")
        return None
