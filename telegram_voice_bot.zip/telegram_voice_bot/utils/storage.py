"""
Storage utilities for file operations
"""
import json
import os
from typing import List, Dict, Any, Optional

from config import (
    SESSIONS_FILE,
    CONNECTED_CHANNEL_FILE,
    LAST_MSG_ID_FILE
)


def load_sessions() -> List[Dict[str, Any]]:
    """Load saved sessions from file"""
    if os.path.exists(SESSIONS_FILE):
        try:
            with open(SESSIONS_FILE, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading sessions: {e}")
            return []
    return []


def save_sessions(sessions: List[Dict[str, Any]]) -> None:
    """Save sessions to file"""
    try:
        with open(SESSIONS_FILE, 'w') as f:
            json.dump(sessions, f, indent=2)
    except Exception as e:
        print(f"Error saving sessions: {e}")


def load_connected_channel() -> Optional[Dict[str, Any]]:
    """Load connected channel from file"""
    if os.path.exists(CONNECTED_CHANNEL_FILE):
        try:
            with open(CONNECTED_CHANNEL_FILE, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading connected channel: {e}")
            return None
    return None


def save_connected_channel(channel_data: Dict[str, Any]) -> None:
    """Save connected channel to file"""
    try:
        with open(CONNECTED_CHANNEL_FILE, 'w') as f:
            json.dump(channel_data, f, indent=2)
    except Exception as e:
        print(f"Error saving connected channel: {e}")


def load_last_msg_id() -> int:
    """Load last processed message ID"""
    if os.path.exists(LAST_MSG_ID_FILE):
        try:
            with open(LAST_MSG_ID_FILE, 'r') as f:
                return json.load(f).get("last_id", 0)
        except Exception:
            return 0
    return 0


def save_last_msg_id(msg_id: int) -> None:
    """Save last processed message ID"""
    try:
        with open(LAST_MSG_ID_FILE, 'w') as f:
            json.dump({"last_id": msg_id}, f)
    except Exception as e:
        print(f"Error saving last msg id: {e}")


def remove_connected_channel_file() -> None:
    """Remove connected channel file"""
    if os.path.exists(CONNECTED_CHANNEL_FILE):
        os.remove(CONNECTED_CHANNEL_FILE)


def remove_sessions_file() -> None:
    """Remove sessions file"""
    if os.path.exists(SESSIONS_FILE):
        os.remove(SESSIONS_FILE)
