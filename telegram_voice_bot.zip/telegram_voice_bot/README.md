# Telegram Voice Chat Manager Bot

A powerful Telegram bot for managing voice chats with multi-session support and auto-reaction features.

## Features

- **Multi-Session Support**: Add and manage 10-20+ Pyrogram string sessions simultaneously
- **Voice Chat Management**: Join/leave voice chats with all added accounts
- **Auto-Reaction**: Automatically react to channel posts with emojis using Raw API & Polling
- **Session Persistence**: Sessions are saved and persist across bot restarts

## Available Commands

| Command | Description |
|---------|-------------|
| `/start` | Show introduction and available commands |
| `/add <session>` | Add Pyrogram string session(s) |
| `/connect <channel_link>` | Connect to a channel |
| `/join` | Join voice chat in connected channel |
| `/leave` | Leave voice chat in connected channel |
| `/status` | Show bot status and connected sessions |
| `/disconnect` | Disconnect from current channel |
| `/remove` | Remove all saved sessions |

## Project Structure

```
telegram_voice_bot/
├── main.py                 # Entry point
├── config.py               # Configuration settings
├── requirements.txt        # Python dependencies
├── README.md               # This file
├── bot/
│   ├── __init__.py
│   ├── bot.py              # Bot initialization and runner
│   └── handlers.py         # Command handlers
├── services/
│   ├── __init__.py
│   ├── session_manager.py  # Session management
│   ├── voice_chat.py       # Voice chat operations
│   └── reaction_poller.py  # Auto-reaction polling
├── utils/
│   ├── __init__.py
│   ├── helpers.py          # Helper functions
│   └── storage.py          # File storage operations
└── data/                   # Data files directory
    ├── sessions.json       # Saved sessions
    ├── connected_channel.json
    └── last_msg_id.json
```

## Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure Environment Variables

Set the following environment variables:

```bash
export BOT_TOKEN="your_bot_token_from_botfather"
export API_ID="your_api_id_from_my.telegram.org"
export API_HASH="your_api_hash_from_my.telegram.org"
export OWNER_ID="your_telegram_user_id"
```

Or edit the defaults in `config.py`.

### 3. Run the Bot

```bash
python main.py
```

## Getting String Sessions

To use this bot, you need Pyrogram string sessions. You can generate them using:

1. **Using Pyrogram Session Generator Bot** on Telegram
2. **Using the Pyrogram library**:

```python
from pyrogram import Client

app = Client("my_account", api_id=API_ID, api_hash=API_HASH)
app.run()
```

Then copy the session string from the generated `.session` file.

## Usage Example

1. Start the bot with `/start`
2. Add your string sessions with `/add <session_string>`
3. Connect to a channel with `/connect @channel_username`
4. Join voice chat with `/join`
5. The bot will auto-react to new posts in the connected channel

## Bot by

- **Developer**: @KustXoffical
- **Updates**: @kustbots
- **Support**: @kustbotschat

## License

This project is for educational purposes. Use responsibly and in accordance with Telegram's Terms of Service.
