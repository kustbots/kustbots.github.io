"""
Session Manager Service
Handles multiple userbot sessions
"""
import asyncio
from datetime import datetime
from typing import Dict, Any, Optional, List, Tuple

from pyrogram import Client

from config import API_ID, API_HASH
from utils.storage import load_sessions, save_sessions, remove_sessions_file


class SessionManager:
    """Manages multiple userbot sessions"""
    
    def __init__(self):
        self.user_clients: Dict[str, Dict[str, Any]] = {}
        self.main_userbot: Optional[Client] = None
    
    async def create_user_client(self, session_string: str, session_name: str) -> Optional[Client]:
        """Create a userbot client from session string"""
        try:
            client = Client(
                session_name,
                api_id=API_ID,
                api_hash=API_HASH,
                session_string=session_string,
                in_memory=True
            )
            return client
        except Exception as e:
            print(f"Error creating client {session_name}: {e}")
            return None
    
    async def start_user_client(self, client: Client, session_name: str) -> Tuple[bool, Optional[Any]]:
        """Start a userbot client"""
        try:
            if not client.is_connected:
                await client.connect()
            me = await client.get_me()
            return True, me
        except Exception as e:
            print(f"Error starting client {session_name}: {e}")
            return False, None
    
    async def add_session(self, session_string: str) -> Tuple[bool, str, Optional[Any]]:
        """Add a single session"""
        try:
            if len(session_string) < 50:
                return False, "Invalid session string (too short)", None
            
            session_name = f"user_{len(self.user_clients)}_{datetime.now().timestamp()}"
            user_client = await self.create_user_client(session_string, session_name)
            
            if user_client:
                success, me = await self.start_user_client(user_client, session_name)
                if success:
                    self.user_clients[session_string[:20]] = {
                        "client": user_client,
                        "session_string": session_string,
                        "me": me
                    }
                    
                    if self.main_userbot is None:
                        self.main_userbot = user_client
                    
                    return True, "Success", me
                else:
                    return False, "Failed to connect", None
            else:
                return False, "Invalid session", None
                
        except Exception as e:
            return False, str(e), None
    
    async def add_multiple_sessions(self, session_strings: List[str]) -> Tuple[List[Tuple[int, str]], List[Tuple[int, str]]]:
        """Add multiple sessions at once"""
        successful = []
        failed = []
        
        saved_sessions = load_sessions()
        existing_session_strings = [s.get("session_string") for s in saved_sessions]
        
        for i, session_string in enumerate(session_strings):
            try:
                if session_string in existing_session_strings:
                    failed.append((i+1, "Already added"))
                    continue
                
                if len(session_string) < 50:
                    failed.append((i+1, "Invalid session string (too short)"))
                    continue
                
                session_name = f"user_{len(self.user_clients)}_{datetime.now().timestamp()}"
                user_client = await self.create_user_client(session_string, session_name)
                
                if user_client:
                    success, me = await self.start_user_client(user_client, session_name)
                    if success:
                        self.user_clients[session_string[:20]] = {
                            "client": user_client,
                            "session_string": session_string,
                            "me": me
                        }
                        
                        if self.main_userbot is None:
                            self.main_userbot = user_client
                        
                        saved_sessions.append({
                            "session_string": session_string,
                            "added_at": str(datetime.now()),
                            "user_id": me.id if me else None,
                            "username": me.username if me else None,
                            "first_name": me.first_name if me else None
                        })
                        
                        name = me.first_name if me and me.first_name else f"Account {len(successful)+1}"
                        successful.append((i+1, name))
                    else:
                        failed.append((i+1, "Failed to connect"))
                else:
                    failed.append((i+1, "Invalid session"))
                    
            except Exception as e:
                failed.append((i+1, str(e)[:50]))
            
            await asyncio.sleep(0.3)
        
        save_sessions(saved_sessions)
        return successful, failed
    
    async def initialize_all_sessions(self) -> None:
        """Initialize all saved sessions on bot startup"""
        sessions = load_sessions()
        if not sessions:
            print("No saved sessions found.")
            return
        
        print(f"Initializing {len(sessions)} sessions...")
        
        for i, session_data in enumerate(sessions):
            session_string = session_data.get("session_string")
            session_name = f"user_{i}_{datetime.now().timestamp()}"
            
            if session_string:
                client = await self.create_user_client(session_string, session_name)
                if client:
                    success, me = await self.start_user_client(client, session_name)
                    if success:
                        self.user_clients[session_string[:20]] = {
                            "client": client,
                            "session_string": session_string,
                            "me": me
                        }
                        if self.main_userbot is None:
                            self.main_userbot = client
                        print(f"✅ Session {i+1} initialized: {me.first_name if me else 'Unknown'}")
                    else:
                        print(f"❌ Failed to start session {i+1}")
                await asyncio.sleep(0.5)
        
        print(f"Successfully initialized {len(self.user_clients)} sessions")
    
    async def remove_all_sessions(self) -> None:
        """Remove all sessions"""
        for session_key, data in self.user_clients.items():
            try:
                client = data["client"]
                if client.is_connected:
                    await client.disconnect()
            except Exception:
                pass
        
        self.user_clients = {}
        self.main_userbot = None
        remove_sessions_file()
    
    def get_session_count(self) -> int:
        """Get number of active sessions"""
        return len(self.user_clients)
    
    def get_main_userbot(self) -> Optional[Client]:
        """Get the main userbot client"""
        if self.main_userbot:
            return self.main_userbot
        if self.user_clients:
            return list(self.user_clients.values())[0]["client"]
        return None
    
    def has_sessions(self) -> bool:
        """Check if there are any sessions"""
        return len(self.user_clients) > 0
