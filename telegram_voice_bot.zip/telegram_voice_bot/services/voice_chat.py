"""
Voice Chat Manager Service
Handles voice chat join/leave operations
"""
import json
import random
from typing import Tuple, Dict, Any

from pyrogram import Client
from pyrogram.errors import UserAlreadyParticipant
from pyrogram.raw import functions, types

from utils.helpers import get_group_call_input


class VoiceChatManager:
    """Manages voice chat operations"""
    
    def __init__(self, session_manager):
        self.session_manager = session_manager
    
    async def join_voice_chat(self, client: Client, chat_identifier) -> Tuple[bool, str]:
        """Join a voice chat in the specified chat using identifier (username or id)"""
        try:
            # Check if there is an active voice chat
            call = await get_group_call_input(client, chat_identifier)
            
            if not call:
                return False, "No active voice chat found"

            # Use the high-level API to join. 
            # This handles the connection handshake and keep-alives automatically,
            # preventing the bot from leaving automatically after a few seconds.
            await client.join_group_call(
                chat_identifier,
                muted=True,
                video_stopped=True
            )
            return True, "Successfully joined voice chat"
        except UserAlreadyParticipant:
            return True, "Already in voice chat"
        except Exception as e:
            return False, str(e)

    async def leave_voice_chat(self, client: Client, chat_identifier) -> Tuple[bool, str]:
        """Leave voice chat"""
        try:
            # Use the high-level API to leave properly
            await client.leave_group_call(chat_identifier)
            return True, "Successfully left voice chat"
        except Exception as e:
            # If the high level method fails (e.g. not in call), return graceful message
            return True, "Left voice chat (or no active call)"
    
    async def join_all_to_voice_chat(self, chat_identifier: str) -> Tuple[list, list]:
        """Join all sessions to a voice chat"""
        import asyncio
        
        joined = []
        failed = []
        
        for session_key, data in self.session_manager.user_clients.items():
            try:
                user_client = data["client"]
                me = data.get("me")
                
                success, msg = await self.join_voice_chat(user_client, chat_identifier)
                
                name = me.first_name if me and me.first_name else session_key[:10]
                
                if success:
                    joined.append(name)
                else:
                    failed.append((name, msg))
                
            except Exception as e:
                me = data.get("me")
                name = me.first_name if me and me.first_name else session_key[:10]
                failed.append((name, str(e)[:50]))
            
            await asyncio.sleep(0.5)
        
        return joined, failed
    
    async def leave_all_from_voice_chat(self, chat_identifier: str) -> Tuple[list, list]:
        """Leave all sessions from a voice chat"""
        import asyncio
        
        left = []
        failed = []
        
        for session_key, data in self.session_manager.user_clients.items():
            try:
                user_client = data["client"]
                me = data.get("me")
                
                success, msg = await self.leave_voice_chat(user_client, chat_identifier)
                
                name = me.first_name if me and me.first_name else session_key[:10]
                if success:
                    left.append(name)
                else:
                    failed.append((name, msg))
                
            except Exception as e:
                me = data.get("me")
                name = me.first_name if me and me.first_name else session_key[:10]
                failed.append((name, str(e)[:50]))
        
        return left, failed