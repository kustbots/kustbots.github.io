"""
Reaction Poller Service
Handles auto-reaction to channel posts using Raw API & Polling
"""
import asyncio
import random
from typing import Optional, Dict, Any

from pyrogram.raw import functions, types

from config import REACTION_EMOJIS
from utils.storage import load_last_msg_id, save_last_msg_id


class ReactionPoller:
    """Handles auto-reaction polling for channel posts"""
    
    def __init__(self, session_manager):
        self.session_manager = session_manager
        self.connected_channel: Optional[Dict[str, Any]] = None
        self._running = False
        self._task = None
    
    def set_connected_channel(self, channel_data: Optional[Dict[str, Any]]) -> None:
        """Set the connected channel"""
        self.connected_channel = channel_data
    
    async def start_polling(self) -> None:
        """Start the reaction polling task"""
        self._running = True
        print("🔄 Reaction Polling Task Started")
        
        while self._running:
            await asyncio.sleep(5)  # Check every 5 seconds
            
            if not self.connected_channel or not self.session_manager.has_sessions():
                continue
            
            await self._poll_and_react()
    
    async def _poll_and_react(self) -> None:
        """Poll for new messages and react"""
        chat_id = self.connected_channel.get("chat_id")
        chat_username = self.connected_channel.get("username")
        channel_name = self.connected_channel.get("title", "Unknown")
        
        # Use username for resolution to avoid CHANNEL_INVALID errors
        chat_identifier = f"@{chat_username}" if chat_username else chat_id
        
        # Load last processed message ID
        last_msg_id = load_last_msg_id()
        
        try:
            # Use the main userbot to check for new messages
            fetch_client = self.session_manager.get_main_userbot()
            
            if not fetch_client:
                return
            
            # Fetch last message
            messages = []
            async for msg in fetch_client.get_chat_history(chat_identifier, limit=1):
                messages.append(msg)
            
            if messages:
                latest_msg = messages[0]
                
                # If new message found
                if latest_msg.id > last_msg_id:
                    print(f"🔔 New message found in {channel_name}: {latest_msg.id}")
                    save_last_msg_id(latest_msg.id)
                    
                    # React from all userbots using Raw API
                    # Each userbot picks a DIFFERENT random emoji
                    await self._react_with_all_sessions(chat_identifier, latest_msg.id)
                    
        except Exception as e:
            print(f"Error in polling task: {e}")
            await asyncio.sleep(10)  # Wait longer on error
    
    async def _react_with_all_sessions(self, chat_identifier: str, msg_id: int) -> None:
        """React to a message with all sessions"""
        for session_key, data in self.session_manager.user_clients.items():
            try:
                # Pick a unique random emoji for each userbot
                emoji = random.choice(REACTION_EMOJIS)
                
                u_client = data["client"]
                
                # Resolve peer for this client
                peer = await u_client.resolve_peer(chat_identifier)
                
                # Send Reaction using Raw API
                await u_client.invoke(
                    functions.messages.SendReaction(
                        peer=peer,
                        msg_id=msg_id,
                        reaction=[types.ReactionEmoji(emoticon=emoji)]
                    )
                )
                print(f"  ✅ Reacted via {session_key} with {emoji}")
                await asyncio.sleep(0.3)  # Small delay to avoid flood
            except Exception as e:
                print(f"  ❌ Failed to react via {session_key}: {str(e)[:50]}")
    
    def stop_polling(self) -> None:
        """Stop the polling task"""
        self._running = False
        if self._task:
            self._task.cancel()
    
    def start_background_task(self) -> asyncio.Task:
        """Start polling as a background task"""
        self._task = asyncio.create_task(self.start_polling())
        return self._task
