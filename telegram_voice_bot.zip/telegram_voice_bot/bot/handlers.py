"""
Bot Command Handlers
All command handlers for the Telegram bot
"""
import asyncio
import os
from datetime import datetime
from typing import TYPE_CHECKING

from pyrogram import Client, filters, enums
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import ChannelPrivate, PeerIdInvalid

from config import OWNER_ID
from utils.helpers import is_owner
from utils.storage import (
    save_connected_channel,
    load_connected_channel,
    remove_connected_channel_file,
    save_last_msg_id
)

if TYPE_CHECKING:
    from services.session_manager import SessionManager
    from services.voice_chat import VoiceChatManager
    from services.reaction_poller import ReactionPoller


class BotHandlers:
    """Container for all bot command handlers"""
    
    def __init__(
        self,
        session_manager: "SessionManager",
        voice_chat_manager: "VoiceChatManager",
        reaction_poller: "ReactionPoller"
    ):
        self.session_manager = session_manager
        self.voice_chat_manager = voice_chat_manager
        self.reaction_poller = reaction_poller
    
    async def start_command(self, client: Client, message: Message):
        """Handle /start command"""
        if not await is_owner(message):
            await message.reply("⚠️ **Access Denied!**\n\nYou are not authorized to use this bot.")
            return
        
        intro_text = """
🤖 **Welcome to Voice Chat Manager Bot!**

**Available Commands:**

📌 `/start` - Show this introduction message
📌 `/add <session>` - Add Pyrogram string session(s)
   • Can add multiple sessions at once (separated by newlines)
   • Supports 10-20+ accounts simultaneously
   
📌 `/connect <channel_link>` - Connect to a channel
   • Use channel username or invite link
   
📌 `/join` - Join voice chat in connected channel
   • All added accounts will join the VC
   
📌 `/leave` - Leave voice chat in connected channel
   • All accounts will leave the VC
   
📌 `/status` - Show bot status and connected sessions
📌 `/disconnect` - Disconnect from current channel
📌 `/remove` - Remove all saved sessions

**Features:**
✅ Multi-session support (10-20+ accounts)
✅ Auto-react to channel posts with emojis (Polling + Raw API)
✅ Voice chat management
✅ Session persistence across restarts

**Bot by:** @KustXoffical
"""
        
        await message.reply(
            intro_text,
            parse_mode=enums.ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📢 Updates", url="https://t.me/kustbots"),
                 InlineKeyboardButton("👤 Developer", url="https://t.me/KustXoffical")],
                [InlineKeyboardButton("💬 Support", url="https://t.me/kustbotschat")]
            ])
        )

    async def add_session_command(self, client: Client, message: Message):
        """Handle /add command to add string sessions"""
        if not await is_owner(message):
            await message.reply("⚠️ **Access Denied!**")
            return
        
        if len(message.text.split(maxsplit=1)) < 2:
            await message.reply(
                "**Usage:** `/add <session_string>`\n\n"
                "**Multiple Sessions:**\n"
                "Reply to a message containing multiple session strings (one per line)\n"
                "or use:\n`/add session1`\n`/add session2`\n\n"
                "**Tip:** You can add 10-20+ sessions at once by sending them in a single message "
                "(one session per line)!",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return
        
        content = message.text.split(maxsplit=1)[1].strip()
        
        if message.reply_to_message and message.reply_to_message.text:
            content = message.reply_to_message.text
        
        session_strings = [s.strip() for s in content.split('\n') if s.strip()]
        
        if not session_strings:
            await message.reply("❌ No valid session strings found!")
            return
        
        status_msg = await message.reply(f"🔄 Processing {len(session_strings)} session(s)...")
        
        successful, failed = await self.session_manager.add_multiple_sessions(session_strings)
        
        result_text = f"📊 **Session Addition Results**\n\n"
        result_text += f"✅ **Successful:** {len(successful)}/{len(session_strings)}\n"
        
        if successful:
            result_text += "\n**Added Accounts:**\n"
            for idx, name in successful:
                result_text += f"  {idx}. {name}\n"
        
        if failed:
            result_text += f"\n❌ **Failed:** {len(failed)}\n"
            for idx, reason in failed[:10]:
                result_text += f"  {idx}. {reason}\n"
            if len(failed) > 10:
                result_text += f"  ... and {len(failed) - 10} more\n"
        
        await status_msg.edit(result_text, parse_mode=enums.ParseMode.MARKDOWN)

    async def connect_channel_command(self, client: Client, message: Message):
        """Handle /connect command to connect to a channel"""
        if not await is_owner(message):
            await message.reply("⚠️ **Access Denied!**")
            return
        
        if len(message.text.split(maxsplit=1)) < 2:
            await message.reply(
                "**Usage:** `/connect <channel_link>`\n\n"
                "**Examples:**\n"
                "• `/connect @channel_username`\n"
                "• `/connect https://t.me/channel_username`\n"
                "• `/connect -1001234567890`",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            return
        
        if not self.session_manager.has_sessions():
            await message.reply("❌ No sessions added! Use `/add` to add sessions first.")
            return
        
        channel_input = message.text.split(maxsplit=1)[1].strip()
        
        status_msg = await message.reply("🔄 Connecting to channel...")
        
        user_client = self.session_manager.get_main_userbot()
        
        try:
            if channel_input.startswith("-100"):
                chat_id = int(channel_input)
                chat = await user_client.get_chat(chat_id)
            elif channel_input.startswith("@"):
                chat = await user_client.get_chat(channel_input)
            elif "t.me/" in channel_input:
                username = channel_input.split("t.me/")[-1].split("/")[0].split("?")[0]
                chat = await user_client.get_chat(f"@{username}")
            else:
                chat = await user_client.get_chat(f"@{channel_input}")
            
            connected_channel = {
                "chat_id": chat.id,
                "username": chat.username,
                "title": chat.title,
                "connected_at": str(datetime.now())
            }
            save_connected_channel(connected_channel)
            
            # Update reaction poller with new channel
            self.reaction_poller.set_connected_channel(connected_channel)
            
            # Set the last message ID to the current latest message to avoid reacting to history
            async for msg in user_client.get_chat_history(chat.id, limit=1):
                save_last_msg_id(msg.id)
                break
            
            await status_msg.edit(
                f"✅ **Successfully Connected!**\n\n"
                f"**Channel:** {chat.title}\n"
                f"**Username:** @{chat.username if chat.username else 'N/A'}\n"
                f"**Chat ID:** `{chat.id}`\n\n"
                f"Use `/join` to join voice chat.\n"
                f"Bot will auto-react to new posts via polling!",
                parse_mode=enums.ParseMode.MARKDOWN
            )
            
        except ChannelPrivate:
            await status_msg.edit("❌ Channel is private. Make sure the account is a member.")
        except PeerIdInvalid:
            await status_msg.edit("❌ Invalid channel. Please check the link/username.")
        except Exception as e:
            await status_msg.edit(f"❌ **Error:** `{str(e)}`", parse_mode=enums.ParseMode.MARKDOWN)

    async def join_command(self, client: Client, message: Message):
        """Handle /join command to join voice chat"""
        if not await is_owner(message):
            await message.reply("⚠️ **Access Denied!**")
            return
        
        connected_channel = load_connected_channel()
        
        if not connected_channel:
            await message.reply("❌ No channel connected! Use `/connect` first.")
            return
        
        if not self.session_manager.has_sessions():
            await message.reply("❌ No sessions added! Use `/add` first.")
            return
        
        chat_id = connected_channel.get("chat_id")
        chat_username = connected_channel.get("username")
        channel_name = connected_channel.get("title", "Unknown")
        
        chat_identifier = f"@{chat_username}" if chat_username else chat_id
        
        status_msg = await message.reply(f"🔄 Joining voice chat in **{channel_name}**...")
        
        joined, failed = await self.voice_chat_manager.join_all_to_voice_chat(chat_identifier)
        
        result_text = f"📊 **Voice Chat Join Results**\n\n"
        result_text += f"📍 **Channel:** {channel_name}\n\n"
        result_text += f"✅ **Joined:** {len(joined)}\n"
        
        if joined:
            for name in joined[:10]:
                result_text += f"  • {name}\n"
            if len(joined) > 10:
                result_text += f"  ... and {len(joined) - 10} more\n"
        
        if failed:
            result_text += f"\n❌ **Failed:** {len(failed)}\n"
            for name, reason in failed[:5]:
                result_text += f"  • {name}: {reason}\n"
        
        await status_msg.edit(result_text, parse_mode=enums.ParseMode.MARKDOWN)

    async def leave_command(self, client: Client, message: Message):
        """Handle /leave command to leave voice chat"""
        if not await is_owner(message):
            await message.reply("⚠️ **Access Denied!**")
            return
        
        connected_channel = load_connected_channel()
        
        if not connected_channel:
            await message.reply("❌ No channel connected! Use `/connect` first.")
            return
        
        if not self.session_manager.has_sessions():
            await message.reply("❌ No sessions added! Use `/add` first.")
            return
        
        chat_id = connected_channel.get("chat_id")
        chat_username = connected_channel.get("username")
        channel_name = connected_channel.get("title", "Unknown")
        
        chat_identifier = f"@{chat_username}" if chat_username else chat_id
        
        status_msg = await message.reply(f"🔄 Leaving voice chat in **{channel_name}**...")
        
        left, failed = await self.voice_chat_manager.leave_all_from_voice_chat(chat_identifier)
        
        result_text = f"📊 **Voice Chat Leave Results**\n\n"
        result_text += f"📍 **Channel:** {channel_name}\n\n"
        result_text += f"✅ **Left:** {len(left)}\n"
        
        if left:
            for name in left[:10]:
                result_text += f"  • {name}\n"
            if len(left) > 10:
                result_text += f"  ... and {len(left) - 10} more\n"
        
        if failed:
            result_text += f"\n❌ **Failed:** {len(failed)}\n"
            for name, reason in failed[:5]:
                result_text += f"  • {name}: {reason}\n"
        
        await status_msg.edit(result_text, parse_mode=enums.ParseMode.MARKDOWN)

    async def status_command(self, client: Client, message: Message):
        """Handle /status command"""
        if not await is_owner(message):
            await message.reply("⚠️ **Access Denied!**")
            return
        
        active_sessions = self.session_manager.get_session_count()
        connected_channel = load_connected_channel()
        
        channel_info = "Not connected"
        if connected_channel:
            channel_info = f"**{connected_channel.get('title')}** (`{connected_channel.get('chat_id')}`)"
        
        status_text = f"📊 **Bot Status**\n\n"
        status_text += f"👥 **Active Sessions:** {active_sessions}\n"
        status_text += f"📢 **Connected Channel:** {channel_info}\n\n"
        
        if self.session_manager.user_clients:
            status_text += "**Sessions List:**\n"
            count = 0
            for session_key, data in self.session_manager.user_clients.items():
                count += 1
                me = data.get("me")
                if me:
                    name = me.first_name or "Unknown"
                    username = f"@{me.username}" if me.username else "No username"
                    status_text += f"  {count}. {name} ({username})\n"
                if count >= 15:
                    status_text += f"  ... and {len(self.session_manager.user_clients) - 15} more\n"
                    break
        
        await message.reply(status_text, parse_mode=enums.ParseMode.MARKDOWN)

    async def disconnect_command(self, client: Client, message: Message):
        """Handle /disconnect command"""
        if not await is_owner(message):
            await message.reply("⚠️ **Access Denied!**")
            return
        
        self.reaction_poller.set_connected_channel(None)
        remove_connected_channel_file()
        
        await message.reply("✅ **Disconnected from channel.**")

    async def remove_sessions_command(self, client: Client, message: Message):
        """Handle /remove command to remove all sessions"""
        if not await is_owner(message):
            await message.reply("⚠️ **Access Denied!**")
            return
        
        await self.session_manager.remove_all_sessions()
        
        await message.reply("✅ **All sessions removed successfully!**")


def setup_handlers(
    bot: Client,
    session_manager: "SessionManager",
    voice_chat_manager: "VoiceChatManager",
    reaction_poller: "ReactionPoller"
) -> None:
    """Setup all bot command handlers"""
    handlers = BotHandlers(session_manager, voice_chat_manager, reaction_poller)
    
    bot.on_message(filters.command("start") & filters.private)(handlers.start_command)
    bot.on_message(filters.command("add") & filters.private)(handlers.add_session_command)
    bot.on_message(filters.command("connect") & filters.private)(handlers.connect_channel_command)
    bot.on_message(filters.command("join") & filters.private)(handlers.join_command)
    bot.on_message(filters.command("leave") & filters.private)(handlers.leave_command)
    bot.on_message(filters.command("status") & filters.private)(handlers.status_command)
    bot.on_message(filters.command("disconnect") & filters.private)(handlers.disconnect_command)
    bot.on_message(filters.command("remove") & filters.private)(handlers.remove_sessions_command)
