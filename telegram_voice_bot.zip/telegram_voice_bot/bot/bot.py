"""
Bot initialization and main runner
"""
import asyncio
from typing import Optional

from pyrogram import Client

from config import BOT_TOKEN, API_ID, API_HASH
from services.session_manager import SessionManager
from services.voice_chat import VoiceChatManager
from services.reaction_poller import ReactionPoller
from utils.storage import load_connected_channel
from .handlers import setup_handlers


class TelegramVoiceBot:
    """Main bot class"""
    
    def __init__(self):
        self.bot: Optional[Client] = None
        self.session_manager: Optional[SessionManager] = None
        self.voice_chat_manager: Optional[VoiceChatManager] = None
        self.reaction_poller: Optional[ReactionPoller] = None
    
    def create_bot(self) -> Client:
        """Create and configure the bot client"""
        self.bot = Client(
            "voice_chat_bot",
            api_id=API_ID,
            api_hash=API_HASH,
            bot_token=BOT_TOKEN
        )
        return self.bot
    
    def initialize_services(self) -> None:
        """Initialize all services"""
        self.session_manager = SessionManager()
        self.voice_chat_manager = VoiceChatManager(self.session_manager)
        self.reaction_poller = ReactionPoller(self.session_manager)
    
    async def setup(self) -> None:
        """Setup the bot and all services"""
        print("=" * 50)
        print("🤖 Telegram Voice Chat Manager Bot")
        print("=" * 50)
        
        # Initialize services
        self.initialize_services()
        
        # Create bot client
        self.create_bot()
        
        # Setup handlers
        setup_handlers(
            self.bot,
            self.session_manager,
            self.voice_chat_manager,
            self.reaction_poller
        )
        
        print("\n🔄 Starting bot...")
        
        # Initialize saved sessions
        await self.session_manager.initialize_all_sessions()
        
        # Load connected channel and set it in reaction poller
        connected_channel = load_connected_channel()
        if connected_channel:
            self.reaction_poller.set_connected_channel(connected_channel)
        
        # Start the reaction polling task
        self.reaction_poller.start_background_task()
        
        # Start the bot
        await self.bot.start()
        
        me = await self.bot.get_me()
        print(f"\n✅ Bot started successfully!")
        print(f"📱 Bot Username: @{me.username}")
        print(f"👤 Bot Name: {me.first_name}")
        print(f"\n💾 Sessions loaded: {self.session_manager.get_session_count()}")
        print(f"📢 Connected channel: {connected_channel.get('title') if connected_channel else 'None'}")
        print("\n" + "=" * 50)
        print("Bot is running! Send /start to begin.")
        print("=" * 50)


def create_bot() -> TelegramVoiceBot:
    """Create a bot instance"""
    return TelegramVoiceBot()


async def run_bot() -> None:
    """Run the bot"""
    bot_instance = create_bot()
    await bot_instance.setup()
    await asyncio.Event().wait()
