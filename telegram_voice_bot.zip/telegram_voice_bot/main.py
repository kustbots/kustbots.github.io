#!/usr/bin/env python3
"""
Telegram Voice Chat Bot with Multi-Session Support

Features:
- /start - Introduction
- /add pyrogram-string-session - Add multiple string sessions (supports 10-20+ accounts)
- /connect channel_link - Connect to a channel
- /join - Join voice chat in connected channel
- /leave - Leave voice chat in connected channel
- Auto-react to channel posts with emojis using Raw API & Polling

Bot by: @KustXoffical
"""
import asyncio
import sys

from config import BOT_TOKEN
from bot import run_bot


def check_setup():
    """Check if bot is properly configured"""
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("\n" + "=" * 50)
        print("⚠️ SETUP REQUIRED!")
        print("=" * 50)
        print("\nPlease set the following environment variables:")
        print("  • BOT_TOKEN - Your Telegram bot token from @BotFather")
        print("  • API_ID - Your API ID from my.telegram.org")
        print("  • API_HASH - Your API Hash from my.telegram.org")
        print("  • OWNER_ID - Your Telegram user ID")
        print("\n" + "=" * 50)
        sys.exit(1)


def main():
    """Main entry point"""
    check_setup()
    
    try:
        asyncio.run(run_bot())
    except KeyboardInterrupt:
        print("\n\n👋 Bot stopped by user. Goodbye!")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
